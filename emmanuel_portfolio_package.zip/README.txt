Emmanuel Boame — Portfolio package

Files included:
- index.html (open this in a browser to view the portfolio)
- assets/ (contains images and CV files)
- Emmanuel_Boame_CV_with_photo.pdf (your CV)
- Emmanuel_Boame_CV.docx (editable resume)

How to use:
1. Unzip this package.
2. Open index.html in any browser to preview locally.
3. To host on GitHub Pages: create a new repo, upload the files, and enable Pages from main branch.
